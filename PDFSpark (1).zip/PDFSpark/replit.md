# Overview

This is a comprehensive PDF processing web application called "PDF Hub" - a professional PDF management platform with 26+ tools for document processing, conversion, and optimization. The application provides various PDF manipulation tools like merge, split, compress, and format conversion with a focus on AdSense compliance and revenue generation through strategic ad placements.

The application features a React frontend with a modern UI built using shadcn/ui components and Tailwind CSS, paired with an Express.js backend that handles file processing operations. It's designed as a complete PDF tool suite where users can upload PDF files and perform various operations through an intuitive web interface with dark/light theme support.

**Key Features for AdSense Compliance:**
- Original branding and content (PDF Hub)
- Strategic ad placements throughout the application
- Legal pages (Privacy Policy, Terms of Service, About, Blog)
- SEO optimization with structured data
- Professional UI/UX design
- Comprehensive tool suite with 26+ PDF processing tools

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React with TypeScript using Vite as the build tool
- **Routing**: wouter for client-side routing with pages for Home, ToolPage, and NotFound
- **UI Framework**: shadcn/ui components built on Radix UI primitives with Tailwind CSS for styling
- **State Management**: TanStack Query (React Query) for server state management and caching
- **Styling**: Tailwind CSS with custom CSS variables for theming, supporting both light and dark modes
- **Component Structure**: Modular component architecture with reusable UI components in `/components/ui/`

## Backend Architecture
- **Framework**: Express.js with TypeScript running on Node.js
- **File Upload**: Multer middleware for handling multipart/form-data file uploads with 50MB size limit
- **Storage Layer**: Abstracted storage interface (IStorage) with in-memory implementation (MemStorage) for development
- **API Design**: RESTful API endpoints under `/api/` prefix for file operations and job management
- **Development Server**: Vite integration for hot module replacement in development mode

## Data Storage Solutions
- **Database**: PostgreSQL using Drizzle ORM for type-safe database operations
- **Connection**: Neon Database serverless PostgreSQL instance
- **Schema**: Four main entities - users, files, jobs, and workflows with proper foreign key relationships
- **File Storage**: Local filesystem storage for uploaded files in `/uploads/` directory
- **Session Management**: Prepared for PostgreSQL session storage using connect-pg-simple

## Authentication and Authorization
- **User System**: Basic user authentication with username/password stored in users table
- **Session Management**: Express session middleware ready for implementation
- **File Association**: Files can be associated with users or allow anonymous uploads
- **Job Tracking**: Jobs linked to users for processing history and status tracking

## External Dependencies
- **Database**: Neon Database (PostgreSQL serverless) via @neondatabase/serverless
- **ORM**: Drizzle ORM with drizzle-kit for migrations and schema management
- **UI Components**: Extensive Radix UI component library for accessible, unstyled components
- **File Processing**: Multer for file upload handling (PDF processing tools to be implemented)
- **Styling**: Tailwind CSS with PostCSS for build-time CSS processing
- **Form Handling**: React Hook Form with Zod for validation via @hookform/resolvers
- **Date Utilities**: date-fns for date manipulation and formatting
- **Development Tools**: Replit-specific plugins for enhanced development experience