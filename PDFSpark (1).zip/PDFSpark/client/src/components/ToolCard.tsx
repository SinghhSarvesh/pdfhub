import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useLocation } from "wouter";
import { 
  FileText, 
  Scissors, 
  Archive, 
  FileImage, 
  Images, 
  PenTool,
  Stamp,
  RotateCcw,
  Code,
  Unlock,
  Lock,
  ArrowUpDown,
  Wrench,
  ListOrdered,
  Camera,
  Search,
  Columns,
  Eraser,
  Crop,
  Edit
} from "lucide-react";

interface ToolCardProps {
  tool: {
    id: string;
    name: string;
    description: string;
    icon: string;
    category: string;
    gradient: string;
    popular?: boolean;
    isNew?: boolean;
  };
}

const iconMap = {
  "compress-arrows-alt": FileText,
  "scissors": Scissors,
  "compress": Archive,
  "file-word": FileText,
  "file-powerpoint": FileText,
  "file-excel": FileText,
  "edit": Edit,
  "image": FileImage,
  "images": Images,
  "signature": PenTool,
  "stamp": Stamp,
  "redo": RotateCcw,
  "code": Code,
  "unlock": Unlock,
  "lock": Lock,
  "sort": ArrowUpDown,
  "archive": Archive,
  "wrench": Wrench,
  "list-ol": ListOrdered,
  "camera": Camera,
  "search": Search,
  "columns": Columns,
  "eraser": Eraser,
  "crop": Crop,
};

export function ToolCard({ tool }: ToolCardProps) {
  const [, navigate] = useLocation();
  const IconComponent = iconMap[tool.icon as keyof typeof iconMap] || FileText;

  const handleClick = () => {
    navigate(`/tool/${tool.id}`);
  };

  return (
    <Card 
      className="bg-white dark:bg-gray-800 rounded-2xl shadow-sm hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 cursor-pointer animate-fade-in"
      onClick={handleClick}
      data-testid={`card-tool-${tool.id}`}
      data-category={tool.category}
    >
      <CardContent className="p-6">
        <div className={`flex items-center justify-center w-16 h-16 bg-gradient-to-br ${tool.gradient} rounded-2xl mb-4 mx-auto`}>
          <IconComponent className="text-white h-8 w-8" />
        </div>
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2 text-center">
          {tool.name}
        </h3>
        <p className="text-gray-600 dark:text-gray-300 text-sm text-center mb-4">
          {tool.description}
        </p>
        {(tool.popular || tool.isNew) && (
          <div className="text-center">
            {tool.popular && (
              <Badge variant="secondary" className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">
                ⭐ Popular
              </Badge>
            )}
            {tool.isNew && (
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
                New!
              </Badge>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
