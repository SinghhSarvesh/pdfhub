import { Link } from "wouter";
import { FileText, Mail, MapPin, Phone, Facebook, Twitter, Linkedin, Youtube } from "lucide-react";

export function Footer() {
  return (
    <footer className="bg-gray-900 dark:bg-black text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-brand-red to-brand-pink rounded-xl flex items-center justify-center">
                <FileText className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-bold">PDF Hub</span>
            </div>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Professional PDF processing platform with comprehensive tools for document management, 
              conversion, and optimization. Secure, fast, and reliable PDF solutions for professionals.
            </p>
            <div className="flex space-x-4">
              <Link href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-facebook">
                <Facebook className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-twitter">
                <Twitter className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-linkedin">
                <Linkedin className="h-5 w-5" />
              </Link>
              <Link href="#" className="text-gray-400 hover:text-white transition-colors" data-testid="link-youtube">
                <Youtube className="h-5 w-5" />
              </Link>
            </div>
          </div>

          {/* Product Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Product</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-tools">
                  PDF Tools
                </Link>
              </li>
              <li>
                <Link href="/desktop" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-desktop">
                  Desktop App
                </Link>
              </li>
              <li>
                <Link href="/mobile" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-mobile">
                  Mobile Apps
                </Link>
              </li>
              <li>
                <Link href="/api" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-api">
                  Developer API
                </Link>
              </li>
              <li>
                <Link href="/workflows" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-workflows">
                  Custom Workflows
                </Link>
              </li>
            </ul>
          </div>

          {/* Company Links */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Company</h3>
            <ul className="space-y-3">
              <li>
                <Link href="/about" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-about">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/blog" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-blog">
                  Blog
                </Link>
              </li>
              <li>
                <Link href="/careers" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-careers">
                  Careers
                </Link>
              </li>
              <li>
                <Link href="/press" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-press">
                  Press Kit
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-contact">
                  Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact & Legal */}
          <div>
            <h3 className="text-lg font-semibold mb-6">Support & Legal</h3>
            <ul className="space-y-3 mb-6">
              <li>
                <Link href="/help" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-help">
                  Help Center
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-privacy">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-terms">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/cookies" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-cookies">
                  Cookie Policy
                </Link>
              </li>
              <li>
                <Link href="/security" className="text-gray-300 hover:text-white transition-colors" data-testid="link-footer-security">
                  Security
                </Link>
              </li>
            </ul>
            
            <div className="space-y-2 text-sm text-gray-400">
              <div className="flex items-center">
                <Mail className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>support@pdfhub.app</span>
              </div>
              <div className="flex items-center">
                <Phone className="h-4 w-4 mr-2 flex-shrink-0" />
                <span>+1 (555) 123-4567</span>
              </div>
              <div className="flex items-start">
                <MapPin className="h-4 w-4 mr-2 flex-shrink-0 mt-0.5" />
                <span>123 PDF Street<br />Document City, DC 12345</span>
              </div>
            </div>
          </div>
        </div>

        {/* Bottom Section */}
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="text-gray-400 text-sm mb-4 md:mb-0">
              © 2025 PDF Hub. All rights reserved. | Professional PDF Solutions
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-gray-400">
              <span>🌍 Available in 25+ languages</span>
              <span>🔒 Bank-level security</span>
              <span>⚡ 99.9% uptime</span>
            </div>
          </div>
          
          <div className="mt-4 text-center text-xs text-gray-500">
            This website uses cookies to enhance user experience and to analyze performance and traffic. 
            By continuing to browse this site, you agree to our{" "}
            <Link href="/cookies" className="text-brand-red hover:underline">
              Cookie Policy
            </Link>.
          </div>
        </div>
      </div>
    </footer>
  );
}