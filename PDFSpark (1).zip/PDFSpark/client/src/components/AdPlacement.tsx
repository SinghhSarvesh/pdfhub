import { useEffect, useRef } from "react";

interface AdPlacementProps {
  slot: string;
  format?: "auto" | "rectangle" | "horizontal" | "vertical";
  responsive?: boolean;
  className?: string;
  style?: React.CSSProperties;
}

export function AdPlacement({ 
  slot, 
  format = "auto", 
  responsive = true, 
  className = "",
  style = {}
}: AdPlacementProps) {
  const adRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window !== 'undefined' && window.adsbygoogle) {
      try {
        (window.adsbygoogle = window.adsbygoogle || []).push({});
      } catch (error) {
        console.error('AdSense error:', error);
      }
    }
  }, []);

  const adStyle: React.CSSProperties = {
    display: 'block',
    minHeight: '100px',
    ...style
  };

  // AdSense script will be loaded via Google Analytics integration
  // This component provides placement areas for ads
  return (
    <div className={`ad-container ${className}`} ref={adRef}>
      <ins
        className="adsbygoogle"
        style={adStyle}
        data-ad-client="ca-pub-XXXXXXXXXXXXXXXXX" // To be replaced with actual publisher ID
        data-ad-slot={slot}
        data-ad-format={format}
        data-full-width-responsive={responsive.toString()}
        data-testid={`ad-placement-${slot}`}
      />
      
      {/* Fallback content for development/testing */}
      {process.env.NODE_ENV === 'development' && (
        <div className="bg-gray-100 dark:bg-gray-800 border-2 border-dashed border-gray-300 dark:border-gray-600 p-4 text-center text-sm text-gray-500 dark:text-gray-400">
          Ad Placement - Slot: {slot}
          <br />
          Format: {format} | Responsive: {responsive ? 'Yes' : 'No'}
        </div>
      )}
    </div>
  );
}

// Predefined ad slots for common placements
export const AdSlots = {
  HEADER_BANNER: "header-banner",
  SIDEBAR_VERTICAL: "sidebar-vertical", 
  CONTENT_RECTANGLE: "content-rectangle",
  FOOTER_BANNER: "footer-banner",
  TOOL_PAGE_TOP: "tool-page-top",
  TOOL_PAGE_BOTTOM: "tool-page-bottom",
  BLOG_ARTICLE: "blog-article",
  HOMEPAGE_FEATURED: "homepage-featured",
} as const;