import { Link } from "wouter";
import { Moon, Sun, Menu, FileText } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { Button } from "@/components/ui/button";

export function Header() {
  const { theme, toggleTheme } = useTheme();

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm border-b border-gray-200 dark:border-gray-700 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3" data-testid="link-home">
              <div className="w-10 h-10 bg-gradient-to-br from-brand-red to-brand-pink rounded-xl flex items-center justify-center">
                <FileText className="text-white h-6 w-6" />
              </div>
              <span className="text-2xl font-bold text-gray-900 dark:text-white">PDF Hub</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 dark:text-gray-300 hover:text-brand-red transition-colors" data-testid="link-tools">
              Tools
            </Link>
            <Link href="/about" className="text-gray-700 dark:text-gray-300 hover:text-brand-red transition-colors" data-testid="link-about">
              About
            </Link>
            <Link href="/blog" className="text-gray-700 dark:text-gray-300 hover:text-brand-red transition-colors" data-testid="link-blog">
              Blog
            </Link>
            <Link href="/privacy-policy" className="text-gray-700 dark:text-gray-300 hover:text-brand-red transition-colors" data-testid="link-privacy">
              Privacy
            </Link>
          </nav>

          {/* Right Side */}
          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <Button
              variant="outline"
              size="icon"
              onClick={toggleTheme}
              className="bg-gray-100 dark:bg-gray-700"
              data-testid="button-theme-toggle"
            >
              {theme === "light" ? (
                <Moon className="h-5 w-5" />
              ) : (
                <Sun className="h-5 w-5" />
              )}
              <span className="sr-only">Toggle theme</span>
            </Button>
            
            {/* Sign In */}
            <Button
              variant="ghost"
              className="text-gray-700 dark:text-gray-300 hover:text-brand-red transition-colors font-medium"
              data-testid="button-sign-in"
            >
              Sign In
            </Button>
            
            {/* Get Premium */}
            <Button
              className="bg-gradient-to-r from-brand-red to-brand-pink text-white hover:shadow-lg transition-all duration-300 transform hover:-translate-y-0.5"
              data-testid="button-get-premium"
            >
              Get Premium
            </Button>

            {/* Mobile Menu Button */}
            <Button
              variant="outline"
              size="icon"
              className="md:hidden"
              data-testid="button-mobile-menu"
            >
              <Menu className="h-5 w-5" />
              <span className="sr-only">Open menu</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
