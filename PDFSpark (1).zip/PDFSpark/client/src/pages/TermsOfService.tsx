import { Header } from "@/components/Header";
import { Card, CardContent } from "@/components/ui/card";

export default function TermsOfService() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">
            Terms of Service
          </h1>
          <p className="text-gray-600 dark:text-gray-300">
            Last updated: {new Date().toLocaleDateString()}
          </p>
        </div>

        <Card className="bg-white dark:bg-gray-800">
          <CardContent className="p-8 space-y-8">
            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                1. Acceptance of Terms
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  By accessing and using iLovePDF services, you accept and agree to be bound by the terms and provision of this agreement.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                2. Service Description
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  iLovePDF provides online PDF processing tools including but not limited to:
                </p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>PDF merging and splitting</li>
                  <li>PDF compression and optimization</li>
                  <li>PDF format conversion</li>
                  <li>PDF editing and annotation</li>
                  <li>PDF security features</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                3. User Responsibilities
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>You agree to:</p>
                <ul className="list-disc pl-6 space-y-2">
                  <li>Use the service only for lawful purposes</li>
                  <li>Not upload copyrighted material without permission</li>
                  <li>Not attempt to circumvent security measures</li>
                  <li>Not use the service to distribute malware or harmful content</li>
                  <li>Respect the intellectual property rights of others</li>
                </ul>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                4. File Processing and Storage
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  Files uploaded to our service are processed automatically and deleted within 1 hour. We do not claim ownership of any files you upload, and you retain all rights to your content.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                5. Premium Services
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  Premium subscription services are billed monthly or annually. You may cancel your subscription at any time. Refunds are provided according to our refund policy.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                6. Limitation of Liability
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  iLovePDF shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the service.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                7. Service Availability
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  We strive to maintain 99.9% uptime but do not guarantee uninterrupted service. Maintenance windows will be communicated in advance when possible.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                8. Changes to Terms
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting. Your continued use constitutes acceptance of the modified terms.
                </p>
              </div>
            </section>

            <section>
              <h2 className="text-2xl font-semibold text-gray-900 dark:text-white mb-4">
                9. Contact Information
              </h2>
              <div className="space-y-4 text-gray-600 dark:text-gray-300">
                <p>
                  For questions about these Terms of Service, contact us at:
                </p>
                <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                  <p>Email: legal@ilovepdf.com</p>
                  <p>Address: 123 PDF Street, Document City, DC 12345</p>
                </div>
              </div>
            </section>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}