import { useState } from "react";
import { useRoute } from "wouter";
import { Header } from "@/components/Header";
import { FileUpload } from "@/components/FileUpload";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Settings, PlayCircle } from "lucide-react";
import { PDF_TOOLS } from "@/lib/constants";
import { Link } from "wouter";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface ProcessingJob {
  id: string;
  toolType: string;
  status: "pending" | "processing" | "completed" | "failed";
  progress?: number;
  outputFiles?: string[];
  createdAt: string;
}

export default function ToolPage() {
  const [, params] = useRoute("/tool/:toolId");
  const [uploadedFiles, setUploadedFiles] = useState<any[]>([]);
  const [processingJobs, setProcessingJobs] = useState<ProcessingJob[]>([]);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const toolId = params?.toolId;
  const tool = PDF_TOOLS.find(t => t.id === toolId);

  const createJobMutation = useMutation({
    mutationFn: async (jobData: any) => {
      const response = await apiRequest("POST", "/api/jobs", jobData);
      return response.json();
    },
    onSuccess: (newJob: ProcessingJob) => {
      setProcessingJobs(prev => [newJob, ...prev]);
      toast({
        title: "Processing started",
        description: `Your ${tool?.name} job has been queued for processing.`,
      });

      // Poll for job status updates
      const pollInterval = setInterval(async () => {
        try {
          const response = await fetch(`/api/jobs/${newJob.id}`);
          const updatedJob = await response.json();
          
          setProcessingJobs(prev => 
            prev.map(job => 
              job.id === newJob.id 
                ? { ...job, status: updatedJob.status, outputFiles: updatedJob.outputFiles }
                : job
            )
          );

          if (updatedJob.status === "completed" || updatedJob.status === "failed") {
            clearInterval(pollInterval);
            if (updatedJob.status === "completed") {
              toast({
                title: "Processing completed",
                description: "Your files are ready for download!",
              });
            } else {
              toast({
                title: "Processing failed",
                description: "There was an error processing your files.",
                variant: "destructive",
              });
            }
          }
        } catch (error) {
          console.error("Error polling job status:", error);
          clearInterval(pollInterval);
        }
      }, 2000);

      // Clean up interval after 2 minutes
      setTimeout(() => clearInterval(pollInterval), 120000);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to start processing. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleFilesUploaded = (files: any[]) => {
    setUploadedFiles(files);
  };

  const handleStartProcessing = () => {
    if (uploadedFiles.length === 0) {
      toast({
        title: "No files selected",
        description: "Please upload files before starting processing.",
        variant: "destructive",
      });
      return;
    }

    const jobData = {
      toolType: toolId,
      status: "pending",
      inputFiles: uploadedFiles.map(file => ({ 
        id: file.id, 
        name: file.name, 
        size: file.size 
      })),
      settings: {},
    };

    createJobMutation.mutate(jobData);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "pending": return "bg-yellow-500";
      case "processing": return "bg-blue-500";
      case "completed": return "bg-green-500";
      case "failed": return "bg-red-500";
      default: return "bg-gray-500";
    }
  };

  const getStatusText = (status: string) => {
    switch (status) {
      case "pending": return "Pending";
      case "processing": return "Processing";
      case "completed": return "Completed";
      case "failed": return "Failed";
      default: return "Unknown";
    }
  };

  if (!tool) {
    return (
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
        <Header />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <Card className="max-w-md mx-auto">
            <CardContent className="pt-6 text-center">
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
                Tool Not Found
              </h1>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                The requested PDF tool could not be found.
              </p>
              <Link href="/" className="inline-block">
                <Button data-testid="button-back-home">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Back to Home
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tool Header */}
        <div className="mb-8">
          <Link href="/" className="inline-flex items-center text-brand-blue hover:text-blue-700 mb-4" data-testid="link-back">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Tools
          </Link>
          
          <div className="flex items-center space-x-4 mb-4">
            <div className={`w-16 h-16 bg-gradient-to-br ${tool.gradient} rounded-2xl flex items-center justify-center`}>
              <Settings className="text-white h-8 w-8" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
                {tool.name}
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                {tool.description}
              </p>
            </div>
            {tool.isNew && (
              <Badge variant="secondary" className="bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300">
                New!
              </Badge>
            )}
            {tool.popular && (
              <Badge variant="secondary" className="bg-blue-100 dark:bg-blue-900/30 text-blue-800 dark:text-blue-300">
                ⭐ Popular
              </Badge>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* File Upload and Processing */}
          <div className="lg:col-span-2 space-y-6">
            {/* File Upload */}
            <Card>
              <CardHeader>
                <CardTitle>Upload Files</CardTitle>
              </CardHeader>
              <CardContent>
                <FileUpload 
                  onFilesUploaded={handleFilesUploaded}
                  accept=".pdf"
                  maxFiles={10}
                />
              </CardContent>
            </Card>

            {/* Processing Controls */}
            {uploadedFiles.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Processing Options</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-300">
                        {uploadedFiles.length} file(s) ready for processing
                      </p>
                    </div>
                    <Button
                      onClick={handleStartProcessing}
                      disabled={createJobMutation.isPending}
                      className="bg-brand-blue text-white hover:bg-blue-700"
                      data-testid="button-start-processing"
                    >
                      <PlayCircle className="mr-2 h-4 w-4" />
                      {createJobMutation.isPending ? "Starting..." : `Start ${tool.name}`}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            )}

            {/* Processing Jobs */}
            {processingJobs.length > 0 && (
              <Card>
                <CardHeader>
                  <CardTitle>Processing Queue</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {processingJobs.map((job) => (
                      <div
                        key={job.id}
                        className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg"
                        data-testid={`job-item-${job.id}`}
                      >
                        <div className="flex items-center space-x-3">
                          <div className={`w-3 h-3 rounded-full ${getStatusColor(job.status)}`} />
                          <div>
                            <p className="font-medium text-gray-900 dark:text-white">
                              {tool.name} Job
                            </p>
                            <p className="text-sm text-gray-500 dark:text-gray-400">
                              {getStatusText(job.status)} • {new Date(job.createdAt).toLocaleTimeString()}
                            </p>
                          </div>
                        </div>
                        
                        {job.status === "processing" && (
                          <div className="flex-1 max-w-xs mx-4">
                            <Progress value={job.progress || 50} className="h-2" />
                          </div>
                        )}
                        
                        {job.status === "completed" && job.outputFiles && (
                          <Button
                            variant="outline"
                            size="sm"
                            data-testid={`button-download-${job.id}`}
                          >
                            <Download className="mr-2 h-4 w-4" />
                            Download
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Tool Info */}
            <Card>
              <CardHeader>
                <CardTitle>Tool Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                    Supported Formats
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    PDF files up to 50MB
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                    Processing Time
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Usually takes 2-10 seconds
                  </p>
                </div>
                
                <div>
                  <h4 className="font-medium text-gray-900 dark:text-white mb-2">
                    Security
                  </h4>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    Files are automatically deleted after 1 hour
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Related Tools */}
            <Card>
              <CardHeader>
                <CardTitle>Related Tools</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {PDF_TOOLS
                    .filter(t => t.category === tool.category && t.id !== tool.id)
                    .slice(0, 3)
                    .map((relatedTool) => (
                      <Link key={relatedTool.id} href={`/tool/${relatedTool.id}`}>
                        <div className="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700 cursor-pointer">
                          <div className={`w-8 h-8 bg-gradient-to-br ${relatedTool.gradient} rounded-lg flex items-center justify-center`}>
                            <Settings className="text-white h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-900 dark:text-white">
                              {relatedTool.name}
                            </p>
                          </div>
                        </div>
                      </Link>
                    ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
