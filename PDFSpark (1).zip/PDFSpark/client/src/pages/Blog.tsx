import { Header } from "@/components/Header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, Clock, ArrowRight, User } from "lucide-react";
import { Link } from "wouter";

const blogPosts = [
  {
    id: 1,
    title: "10 Essential PDF Tips Every Professional Should Know",
    excerpt: "Discover advanced PDF techniques that will save you hours of work every week. From batch processing to automated workflows, these tips will transform how you handle documents.",
    author: "Sarah Chen",
    publishDate: "2024-01-15",
    readTime: "5 min read",
    category: "Tips & Tricks",
    featured: true,
    image: "📄",
  },
  {
    id: 2,
    title: "The Complete Guide to PDF Security and Encryption",
    excerpt: "Learn how to protect your sensitive documents with advanced encryption, password protection, and digital signatures. A comprehensive guide to PDF security best practices.",
    author: "Michael Rodriguez",
    publishDate: "2024-01-12",
    readTime: "8 min read",
    category: "Security",
    featured: false,
    image: "🔐",
  },
  {
    id: 3,
    title: "How to Optimize PDFs for Web and Mobile",
    excerpt: "Reduce file sizes without compromising quality. Learn the best compression techniques and optimization strategies for web-ready PDFs.",
    author: "Emily Johnson",
    publishDate: "2024-01-10",
    readTime: "6 min read",
    category: "Optimization",
    featured: false,
    image: "⚡",
  },
  {
    id: 4,
    title: "Converting Documents: Best Practices and Common Pitfalls",
    excerpt: "Master the art of document conversion with our comprehensive guide. Learn when to use different formats and how to maintain formatting integrity.",
    author: "David Kim",
    publishDate: "2024-01-08",
    readTime: "7 min read",
    category: "Conversion",
    featured: false,
    image: "🔄",
  },
  {
    id: 5,
    title: "Workflow Automation: Streamline Your Document Processing",
    excerpt: "Build custom workflows that automatically process your documents. Save time with automated PDF operations and batch processing techniques.",
    author: "Lisa Wang",
    publishDate: "2024-01-05",
    readTime: "10 min read",
    category: "Automation",
    featured: false,
    image: "🤖",
  },
  {
    id: 6,
    title: "Digital Signatures: Everything You Need to Know",
    excerpt: "Understand the legal aspects of digital signatures, how they work, and how to implement them in your document workflow for better security and compliance.",
    author: "John Martinez",
    publishDate: "2024-01-03",
    readTime: "9 min read",
    category: "Legal",
    featured: false,
    image: "✍️",
  },
];

const categories = ["All", "Tips & Tricks", "Security", "Optimization", "Conversion", "Automation", "Legal"];

export default function Blog() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
            PDF Knowledge Hub
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            Expert tips, tutorials, and insights to help you master PDF processing. 
            Learn from our team of document experts and improve your workflow.
          </p>
        </div>

        {/* Featured Post */}
        {blogPosts.find(post => post.featured) && (
          <Card className="bg-gradient-to-r from-brand-red to-brand-pink text-white mb-12">
            <CardContent className="p-8">
              <div className="flex items-center mb-4">
                <Badge variant="secondary" className="bg-white/20 text-white border-none">
                  Featured Post
                </Badge>
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                  <h2 className="text-3xl font-bold mb-4">
                    {blogPosts.find(post => post.featured)?.title}
                  </h2>
                  <p className="text-lg opacity-90 mb-6">
                    {blogPosts.find(post => post.featured)?.excerpt}
                  </p>
                  <div className="flex items-center space-x-6 text-sm opacity-80 mb-6">
                    <div className="flex items-center">
                      <User className="h-4 w-4 mr-2" />
                      {blogPosts.find(post => post.featured)?.author}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-2" />
                      {new Date(blogPosts.find(post => post.featured)?.publishDate || '').toLocaleDateString()}
                    </div>
                    <div className="flex items-center">
                      <Clock className="h-4 w-4 mr-2" />
                      {blogPosts.find(post => post.featured)?.readTime}
                    </div>
                  </div>
                  <Button
                    className="bg-white text-brand-red hover:bg-gray-100"
                    data-testid="button-read-featured"
                  >
                    Read Full Article
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                <div className="text-center">
                  <div className="text-8xl mb-4">
                    {blogPosts.find(post => post.featured)?.image}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Category Filter */}
        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {categories.map((category) => (
            <Button
              key={category}
              variant="outline"
              className="bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-brand-red hover:text-white transition-colors"
              data-testid={`button-filter-${category.toLowerCase().replace(/\s+/g, '-')}`}
            >
              {category}
            </Button>
          ))}
        </div>

        {/* Blog Posts Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {blogPosts.filter(post => !post.featured).map((post) => (
            <Card key={post.id} className="bg-white dark:bg-gray-800 hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="text-4xl mb-4 text-center">
                  {post.image}
                </div>
                <div className="flex items-center justify-between mb-3">
                  <Badge variant="secondary" className="text-xs">
                    {post.category}
                  </Badge>
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    <Clock className="h-3 w-3 mr-1" />
                    {post.readTime}
                  </div>
                </div>
                <CardTitle className="text-lg font-semibold text-gray-900 dark:text-white line-clamp-2">
                  {post.title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-600 dark:text-gray-300 text-sm mb-4 line-clamp-3">
                  {post.excerpt}
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center text-xs text-gray-500 dark:text-gray-400">
                    <User className="h-3 w-3 mr-1" />
                    {post.author}
                  </div>
                  <div className="text-xs text-gray-500 dark:text-gray-400">
                    {new Date(post.publishDate).toLocaleDateString()}
                  </div>
                </div>
                <Button
                  variant="ghost"
                  className="w-full mt-4 text-brand-red hover:bg-red-50 dark:hover:bg-red-950/20"
                  data-testid={`button-read-post-${post.id}`}
                >
                  Read More
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Newsletter Signup */}
        <Card className="bg-gray-100 dark:bg-gray-800">
          <CardContent className="p-8 text-center">
            <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-4">
              Stay Updated with PDF Tips
            </h2>
            <p className="text-gray-600 dark:text-gray-300 mb-6 max-w-2xl mx-auto">
              Get weekly tips, tutorials, and industry insights delivered to your inbox. 
              Join thousands of professionals who trust our expertise.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email address"
                className="flex-1 px-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-700 text-gray-900 dark:text-white"
                data-testid="input-newsletter-email"
              />
              <Button
                className="bg-brand-red text-white hover:bg-red-600"
                data-testid="button-subscribe-newsletter"
              >
                Subscribe
              </Button>
            </div>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-3">
              No spam. Unsubscribe anytime.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}