import { Header } from "@/components/Header";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { FileText, Shield, Zap, Users, Award, Globe } from "lucide-react";

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">
            About iLovePDF
          </h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
            We're passionate about making PDF management simple, secure, and accessible to everyone. 
            Our mission is to provide the most comprehensive suite of PDF tools available online.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
          {[
            { number: "10M+", label: "Files Processed Monthly", icon: FileText },
            { number: "26+", label: "PDF Tools Available", icon: Zap },
            { number: "150+", label: "Countries Served", icon: Globe },
            { number: "99.9%", label: "Uptime Guarantee", icon: Shield },
          ].map((stat, index) => (
            <Card key={index} className="bg-white dark:bg-gray-800 text-center">
              <CardContent className="p-6">
                <stat.icon className="h-10 w-10 text-brand-red mx-auto mb-4" />
                <div className="text-3xl font-bold text-gray-900 dark:text-white mb-2">
                  {stat.number}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-300">
                  {stat.label}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 mb-16">
          <div>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Our Story
            </h2>
            <div className="space-y-4 text-gray-600 dark:text-gray-300">
              <p>
                Founded in 2015, iLovePDF started with a simple vision: to make PDF processing 
                accessible to everyone, regardless of technical expertise. What began as a small 
                project has grown into the world's most trusted PDF platform.
              </p>
              <p>
                Today, we serve millions of users worldwide, from students and professionals 
                to large enterprises. Our commitment to security, privacy, and user experience 
                has made us the go-to solution for PDF management.
              </p>
              <p>
                We believe that powerful tools should be simple to use, which is why we've 
                designed our platform to be intuitive while offering professional-grade capabilities.
              </p>
            </div>
          </div>
          
          <div>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
              Our Values
            </h2>
            <div className="space-y-6">
              {[
                {
                  icon: Shield,
                  title: "Security First",
                  description: "Your files are encrypted and automatically deleted within 1 hour. We never store or access your content."
                },
                {
                  icon: Zap,
                  title: "Lightning Fast",
                  description: "Our optimized servers process millions of files daily with industry-leading speed and reliability."
                },
                {
                  icon: Users,
                  title: "User-Centric",
                  description: "Every feature is designed with our users in mind, ensuring the best possible experience."
                },
              ].map((value, index) => (
                <div key={index} className="flex items-start space-x-4">
                  <div className="w-12 h-12 bg-brand-red rounded-xl flex items-center justify-center flex-shrink-0">
                    <value.icon className="text-white h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-gray-900 dark:text-white mb-2">
                      {value.title}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-300 text-sm">
                      {value.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Team Section */}
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Meet Our Team
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-12 max-w-2xl mx-auto">
            We're a diverse team of engineers, designers, and PDF enthusiasts working 
            together to build the best PDF platform in the world.
          </p>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                name: "Sarah Chen",
                role: "CEO & Founder",
                bio: "Former Adobe engineer with 10+ years in document technology."
              },
              {
                name: "Michael Rodriguez",
                role: "CTO",
                bio: "Full-stack developer passionate about scalable architecture."
              },
              {
                name: "Emily Johnson",
                role: "Head of Security",
                bio: "Cybersecurity expert ensuring your data stays protected."
              },
            ].map((member, index) => (
              <Card key={index} className="bg-white dark:bg-gray-800">
                <CardContent className="p-6 text-center">
                  <div className="w-20 h-20 bg-gradient-to-br from-brand-red to-brand-pink rounded-full mx-auto mb-4 flex items-center justify-center">
                    <span className="text-white text-2xl font-bold">
                      {member.name.split(' ').map(n => n[0]).join('')}
                    </span>
                  </div>
                  <h3 className="font-semibold text-gray-900 dark:text-white mb-1">
                    {member.name}
                  </h3>
                  <p className="text-brand-red font-medium mb-3">
                    {member.role}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-300">
                    {member.bio}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Recognition Section */}
        <Card className="bg-gradient-to-r from-brand-red to-brand-pink text-white mb-16">
          <CardContent className="p-8 text-center">
            <Award className="h-16 w-16 mx-auto mb-6 opacity-90" />
            <h2 className="text-3xl font-bold mb-4">
              Trusted by Millions Worldwide
            </h2>
            <p className="text-lg opacity-90 mb-6 max-w-2xl mx-auto">
              iLovePDF has been recognized as the leading PDF platform by industry experts 
              and trusted by users in over 150 countries.
            </p>
            <div className="flex flex-wrap justify-center gap-6 text-sm opacity-80">
              <span>✓ ISO27001 Certified</span>
              <span>✓ GDPR Compliant</span>
              <span>✓ SOC 2 Type II</span>
              <span>✓ 99.9% Uptime SLA</span>
            </div>
          </CardContent>
        </Card>

        {/* CTA Section */}
        <div className="text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-6">
            Ready to Get Started?
          </h2>
          <p className="text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            Join millions of users who trust iLovePDF for their document processing needs. 
            Start using our tools for free today.
          </p>
          <div className="space-x-4">
            <Button 
              size="lg"
              className="bg-brand-red text-white hover:bg-red-600"
              data-testid="button-start-free"
            >
              Start for Free
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              data-testid="button-view-pricing"
            >
              View Pricing
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}