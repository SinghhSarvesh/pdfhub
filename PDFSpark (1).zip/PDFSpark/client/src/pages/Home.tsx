import React, { useState } from "react";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { SEOHead } from "@/components/SEOHead";
import { AdPlacement, AdSlots } from "@/components/AdPlacement";
import { FileUpload } from "@/components/FileUpload";
import { ToolCard } from "@/components/ToolCard";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { PDF_TOOLS, TOOL_CATEGORIES } from "@/lib/constants";
import { 
  Settings, 
  Download, 
  Smartphone, 
  Monitor, 
  Users, 
  CheckCircle, 
  Crown,
  Shield,
  Tag,
  FileText,
  ArrowRight,
  Star,
  Image
} from "lucide-react";

export default function Home() {
  const [activeFilter, setActiveFilter] = useState("all");
  const [filteredTools, setFilteredTools] = useState(PDF_TOOLS);

  const handleFilterChange = (categoryId: string) => {
    setActiveFilter(categoryId);
    if (categoryId === "all") {
      setFilteredTools(PDF_TOOLS);
    } else {
      setFilteredTools(PDF_TOOLS.filter(tool => tool.category === categoryId));
    }
  };

  const structuredData = {
    "@context": "https://schema.org",
    "@type": "WebApplication",
    "name": "PDF Tools Hub",
    "description": "Free online PDF processing tools for document management, conversion, and optimization",
    "url": window.location.origin,
    "applicationCategory": "ProductivityApplication",
    "operatingSystem": "Web Browser",
    "offers": {
      "@type": "Offer",
      "price": "0",
      "priceCurrency": "USD",
      "name": "Free PDF Processing Tools"
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 transition-colors duration-300">
      <SEOHead
        title="PDF Tools Hub | Free Online PDF Processing & Management Tools"
        description="Professional PDF processing tools for document management, conversion, and optimization. Merge, split, compress, convert and edit PDF files online for free."
        keywords="PDF tools, document processing, PDF converter, file management, online PDF editor, PDF merger, document optimization"
        structuredData={structuredData}
      />
      <Header />

      {/* Header Ad Placement */}
      <AdPlacement slot={AdSlots.HEADER_BANNER} format="horizontal" className="mb-4" />

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-red-50 via-pink-50 to-orange-50 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800 py-16 lg:py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl lg:text-6xl font-bold text-gray-900 dark:text-white mb-6 leading-tight">
              Professional{" "}
              <span className="bg-gradient-to-r from-brand-red to-brand-pink bg-clip-text text-transparent">
                PDF Tools
              </span>{" "}
              for Document Management
            </h1>
            <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 max-w-3xl mx-auto">
              Comprehensive PDF processing suite with 26+ professional tools. Merge, split, compress, convert, and optimize your documents with enterprise-grade security.
            </p>

            <div className="max-w-2xl mx-auto">
              <FileUpload onFilesUploaded={(files) => console.log("Files uploaded:", files)} />
            </div>
          </div>
        </div>
      </section>

      {/* Tools Filter */}
      <section className="bg-white dark:bg-gray-800 py-8 border-b border-gray-200 dark:border-gray-700" id="tools">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {TOOL_CATEGORIES.map((category) => (
              <Button
                key={category.id}
                variant={activeFilter === category.id ? "default" : "outline"}
                className={`px-6 py-3 rounded-xl font-medium transition-colors ${
                  activeFilter === category.id
                    ? "bg-brand-red text-white hover:bg-red-600"
                    : "bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                }`}
                onClick={() => handleFilterChange(category.id)}
                data-testid={`button-filter-${category.id}`}
              >
                {category.name}
              </Button>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Grid */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Featured Ad in Tools Section */}
          <div className="mb-12">
            <AdPlacement slot={AdSlots.HOMEPAGE_FEATURED} format="rectangle" className="max-w-4xl mx-auto" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filteredTools.map((tool, index) => (
              <div key={tool.id}>
                <ToolCard tool={tool} />
                {/* Insert ad after every 8 tools */}
                {(index + 1) % 8 === 0 && (
                  <div className="col-span-full my-8">
                    <AdPlacement slot={`tools-grid-${Math.floor(index / 8)}`} format="horizontal" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Workflows Section */}
      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Create Custom Workflows
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300 max-w-3xl mx-auto">
              Automate your PDF processing with custom workflows. Chain multiple tools together and save time on repetitive tasks.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            <div>
              <Card className="bg-gradient-to-br from-gray-50 to-gray-100 dark:from-gray-700 dark:to-gray-800">
                <CardContent className="p-8">
                  <div className="space-y-4">
                    {[
                      { icon: FileText, name: "Upload PDF", desc: "Select files to process", color: "bg-blue-500" },
                      { icon: Settings, name: "Compress", desc: "Reduce file size", color: "bg-purple-500" },
                      { icon: Star, name: "Add Signature", desc: "Electronic signature", color: "bg-green-500" },
                      { icon: Download, name: "Download", desc: "Get processed file", color: "bg-orange-500" },
                    ].map((step, index) => (
                      <div key={index} className="flex items-center space-x-4">
                        <div className={`w-12 h-12 ${step.color} rounded-xl flex items-center justify-center`}>
                          <step.icon className="text-white h-6 w-6" />
                        </div>
                        <div className="flex-1">
                          <div className="text-sm font-medium text-gray-900 dark:text-white">
                            {step.name}
                          </div>
                          <div className="text-xs text-gray-500 dark:text-gray-400">
                            {step.desc}
                          </div>
                        </div>
                        {index < 3 && (
                          <ArrowRight className="h-4 w-4 text-gray-400" />
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-6">
              <Card className="bg-gradient-to-br from-brand-red to-brand-pink text-white">
                <CardContent className="p-8">
                  <h3 className="text-2xl font-bold mb-4">Create Workflow</h3>
                  <p className="mb-6 opacity-90">
                    Build custom workflows with your favorite tools, automate tasks, and reuse them anytime.
                  </p>
                  <Button
                    className="bg-white text-brand-red hover:bg-gray-100 transition-colors"
                    data-testid="button-create-workflow"
                  >
                    <Settings className="mr-2 h-4 w-4" />
                    Create New Workflow
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gray-100 dark:bg-gray-700">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h4 className="font-semibold text-gray-900 dark:text-white">
                      Available Workflows
                    </h4>
                    <Badge variant="secondary" className="text-green-600 dark:text-green-400">
                      1 of 6 free
                    </Badge>
                  </div>
                  <div className="space-y-3">
                    <Card className="bg-white dark:bg-gray-800">
                      <CardContent className="p-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center space-x-3">
                            <div className="w-8 h-8 bg-blue-100 dark:bg-blue-900/30 rounded-lg flex items-center justify-center">
                              <Settings className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                            </div>
                            <div>
                              <div className="text-sm font-medium text-gray-900 dark:text-white">
                                Document Prep
                              </div>
                              <div className="text-xs text-gray-500 dark:text-gray-400">
                                Compress → Watermark → Sign
                              </div>
                            </div>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="text-blue-600 dark:text-blue-400"
                            data-testid="button-run-workflow"
                          >
                            ▶️
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50 dark:bg-gray-900" id="features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
              Work Your Way
            </h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">
              Choose the solution that fits your workflow
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {[
              {
                title: "Work offline with Desktop",
                description: "Batch edit and manage documents locally, with no internet and no limits.",
                icon: Monitor,
                gradient: "from-blue-500 to-blue-600",
                buttonText: "Download Desktop App",
              },
              {
                title: "On-the-go with Mobile",
                description: "Your favorite tools, right in your pocket. Keep working on your projects anytime, anywhere.",
                icon: Smartphone,
                gradient: "from-green-500 to-green-600",
                buttonText: "Get Mobile Apps",
              },
              {
                title: "Built for business",
                description: "Automate document management, onboard teams easily, and scale with flexible plans.",
                icon: Users,
                gradient: "from-purple-500 to-purple-600",
                buttonText: "Explore Business Solutions",
              },
            ].map((feature, index) => (
              <Card key={index} className="bg-white dark:bg-gray-800 hover:shadow-lg transition-shadow">
                <CardContent className="p-8">
                  <div className={`w-16 h-16 bg-gradient-to-br ${feature.gradient} rounded-2xl flex items-center justify-center mb-6 mx-auto`}>
                    <feature.icon className="text-white h-8 w-8" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 dark:text-white mb-3 text-center">
                    {feature.title}
                  </h3>
                  <p className="text-gray-600 dark:text-gray-300 mb-6 text-center">
                    {feature.description}
                  </p>
                  <Button
                    className={`w-full bg-gradient-to-r ${feature.gradient} text-white hover:shadow-lg transition-all`}
                    data-testid={`button-feature-${index}`}
                  >
                    {feature.buttonText}
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Premium Section */}
      <section className="py-16 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500" id="pricing">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="text-white">
              <h2 className="text-4xl font-bold mb-6">Get more with Premium</h2>
              <ul className="space-y-4 text-lg">
                {[
                  "Get full access to iLovePDF and work offline with Desktop",
                  "Edit PDFs, get advanced OCR for scanned documents",
                  "Request secure e-Signatures from others",
                  "Connect tools and create custom workflows",
                  "Priority support and faster processing",
                ].map((feature, index) => (
                  <li key={index} className="flex items-center">
                    <CheckCircle className="mr-3 h-6 w-6 text-green-300 flex-shrink-0" />
                    {feature}
                  </li>
                ))}
              </ul>
              <div className="mt-8">
                <Button
                  size="lg"
                  className="bg-white text-purple-600 hover:bg-gray-100 transition-colors shadow-lg font-bold text-lg px-8 py-4"
                  data-testid="button-get-premium-main"
                >
                  Get Premium Now
                </Button>
                <p className="text-purple-100 mt-3">Starting from $4/month</p>
              </div>
            </div>

            <div className="relative">
              <Card className="bg-white/90 backdrop-blur-sm shadow-2xl">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h4 className="font-semibold text-gray-900">Premium Features</h4>
                      <p className="text-sm text-gray-600">Unlimited processing & advanced tools</p>
                    </div>
                    <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-500 rounded-xl flex items-center justify-center">
                      <Crown className="text-white h-6 w-6" />
                    </div>
                  </div>
                  <div className="space-y-3">
                    {["Advanced OCR", "Batch Processing", "Custom Workflows", "Priority Support"].map((feature, index) => (
                      <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <span className="text-sm font-medium">{feature}</span>
                        <CheckCircle className="h-4 w-4 text-green-500" />
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-16 bg-white dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            The PDF software trusted by millions of users
          </h2>
          <p className="text-xl text-gray-600 dark:text-gray-300 mb-12 max-w-4xl mx-auto">
            iLovePDF is your number one web app for editing PDF with ease. Enjoy all the tools you need to work efficiently with your digital documents while keeping your data safe and secure.
          </p>

          <div className="flex flex-wrap justify-center items-center gap-8">
            {[
              { icon: Tag, title: "ISO27001", subtitle: "Certified" },
              { icon: Shield, title: "Secure HTTPS", subtitle: "Connection" },
              { icon: FileText, title: "PDF Association", subtitle: "Member" },
            ].map((trust, index) => (
              <Card key={index} className="bg-gray-50 dark:bg-gray-700">
                <CardContent className="flex items-center space-x-3 p-6">
                  <trust.icon className="h-8 w-8 text-blue-600" />
                  <div className="text-left">
                    <div className="font-semibold text-gray-900 dark:text-white">
                      {trust.title}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-300">
                      {trust.subtitle}
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Related Products */}
      <section className="py-16 bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-800 dark:via-gray-900 dark:to-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="relative">
              <div className="w-full h-80 bg-gradient-to-br from-pink-100 to-orange-100 dark:from-pink-900/20 dark:to-orange-900/20 rounded-2xl flex items-center justify-center">
                <Image className="h-32 w-32 text-pink-500" />
              </div>
            </div>

            <div>
              <div className="flex items-center space-x-3 mb-6">
                <div className="w-12 h-12 bg-gradient-to-br from-brand-pink to-brand-orange rounded-xl flex items-center justify-center">
                  <Image className="text-white h-6 w-6" />
                </div>
                <span className="text-2xl font-bold text-gray-900 dark:text-white">
                  iLoveIMG
                </span>
              </div>

              <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
                Image editing made simple with iLoveIMG
              </h2>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
                Experience the speed, simplicity, and security you expect from iLovePDF tailored for image editing. Compress, resize, and enhance your images with AI.
              </p>

              <Button
                size="lg"
                className="bg-gradient-to-r from-brand-pink to-brand-orange text-white hover:shadow-lg transition-all transform hover:-translate-y-0.5 font-bold text-lg px-8 py-4"
                data-testid="button-iloveimg"
              >
                Go to iLoveIMG
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
            {[
              {
                title: "Product",
                links: ["Home", "Features", "Pricing", "Tools", "FAQ"],
              },
              {
                title: "Resources",
                links: ["iLovePDF Desktop", "iLovePDF Mobile", "iLoveSign", "iLoveAPI", "iLoveIMG"],
              },
              {
                title: "Solutions",
                links: ["Business", "Education"],
              },
              {
                title: "Legal",
                links: ["Security", "Privacy policy", "Terms & conditions", "Cookies"],
              },
              {
                title: "Company",
                links: ["About us", "Contact us", "Blog", "Press"],
              },
            ].map((section, index) => (
              <div key={index}>
                <h3 className="font-semibold mb-4">{section.title}</h3>
                <ul className="space-y-3 text-gray-300">
                  {section.links.map((link, linkIndex) => (
                    <li key={linkIndex}>
                      <a href="#" className="hover:text-white transition-colors">
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>

          <div className="border-t border-gray-800 mt-12 pt-8">
            <div className="flex flex-col lg:flex-row justify-between items-center space-y-6 lg:space-y-0">
              <div className="flex space-x-4">
                {["Google Play", "App Store", "Mac Store", "Microsoft Store"].map((store, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    className="bg-gray-800 hover:bg-gray-700 border-gray-700"
                  >
                    {store}
                  </Button>
                ))}
              </div>

              <div className="relative">
                <Button
                  variant="outline"
                  className="bg-gray-800 hover:bg-gray-700 border-gray-700"
                  data-testid="button-language-selector"
                >
                  🌍 English ▾
                </Button>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-800 mt-8 pt-8 text-center">
            <p className="text-gray-400">© iLovePDF 2025 ® - Your PDF Editor</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
