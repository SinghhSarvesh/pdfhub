import { type User, type InsertUser, type File, type InsertFile, type Job, type InsertJob, type Workflow, type InsertWorkflow } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // File methods
  getFile(id: string): Promise<File | undefined>;
  getFilesByUser(userId: string): Promise<File[]>;
  createFile(file: InsertFile): Promise<File>;
  deleteFile(id: string): Promise<void>;
  
  // Job methods
  getJob(id: string): Promise<Job | undefined>;
  getJobsByUser(userId: string): Promise<Job[]>;
  createJob(job: InsertJob): Promise<Job>;
  updateJobStatus(id: string, status: string, outputFiles?: any): Promise<Job | undefined>;
  
  // Workflow methods
  getWorkflow(id: string): Promise<Workflow | undefined>;
  getWorkflowsByUser(userId: string): Promise<Workflow[]>;
  createWorkflow(workflow: InsertWorkflow): Promise<Workflow>;
  deleteWorkflow(id: string): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private files: Map<string, File>;
  private jobs: Map<string, Job>;
  private workflows: Map<string, Workflow>;

  constructor() {
    this.users = new Map();
    this.files = new Map();
    this.jobs = new Map();
    this.workflows = new Map();
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // File methods
  async getFile(id: string): Promise<File | undefined> {
    return this.files.get(id);
  }

  async getFilesByUser(userId: string): Promise<File[]> {
    return Array.from(this.files.values()).filter(file => file.userId === userId);
  }

  async createFile(insertFile: InsertFile): Promise<File> {
    const id = randomUUID();
    const file: File = {
      ...insertFile,
      id,
      uploadedAt: new Date(),
      userId: insertFile.userId || null,
    };
    this.files.set(id, file);
    return file;
  }

  async deleteFile(id: string): Promise<void> {
    this.files.delete(id);
  }

  // Job methods
  async getJob(id: string): Promise<Job | undefined> {
    return this.jobs.get(id);
  }

  async getJobsByUser(userId: string): Promise<Job[]> {
    return Array.from(this.jobs.values()).filter(job => job.userId === userId);
  }

  async createJob(insertJob: InsertJob): Promise<Job> {
    const id = randomUUID();
    const job: Job = {
      ...insertJob,
      id,
      status: insertJob.status || "pending",
      userId: insertJob.userId || null,
      createdAt: new Date(),
      completedAt: null,
    };
    this.jobs.set(id, job);
    return job;
  }

  async updateJobStatus(id: string, status: string, outputFiles?: any): Promise<Job | undefined> {
    const job = this.jobs.get(id);
    if (!job) return undefined;

    const updatedJob: Job = {
      ...job,
      status,
      outputFiles,
      completedAt: status === 'completed' || status === 'failed' ? new Date() : null,
    };
    this.jobs.set(id, updatedJob);
    return updatedJob;
  }

  // Workflow methods
  async getWorkflow(id: string): Promise<Workflow | undefined> {
    return this.workflows.get(id);
  }

  async getWorkflowsByUser(userId: string): Promise<Workflow[]> {
    return Array.from(this.workflows.values()).filter(workflow => workflow.userId === userId);
  }

  async createWorkflow(insertWorkflow: InsertWorkflow): Promise<Workflow> {
    const id = randomUUID();
    const workflow: Workflow = {
      ...insertWorkflow,
      id,
      description: insertWorkflow.description || null,
      userId: insertWorkflow.userId || null,
      createdAt: new Date(),
    };
    this.workflows.set(id, workflow);
    return workflow;
  }

  async deleteWorkflow(id: string): Promise<void> {
    this.workflows.delete(id);
  }
}

export const storage = new MemStorage();
